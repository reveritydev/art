# Reverity Portfolio — GitHub Pages

This is the GitHub Pages-ready build of the Reverity portfolio.

## Upload

Put the contents of this folder at the **root of a GitHub repository** so that `index.html` is directly in the repository root.

Recommended repository name for a user site:

`YOUR_GITHUB_USERNAME.github.io`

Then enable GitHub Pages from:

**Repository → Settings → Pages → Deploy from a branch → main → /(root)**

The site will be published at:

`https://YOUR_GITHUB_USERNAME.github.io/`

## Important

- Keep the `assets/` and `data/` folders in the same location as `index.html`.
- `.nojekyll` is included so GitHub Pages serves the project as a plain static site.
- The existing localStorage/admin behavior is unchanged.
