# Reverity Portfolio — v10

- Pale pink / dark editorial portfolio UI.
- WORK, GAMES and CONTACT navigation.
- Full-resolution work viewer with zoom + bounded drag/pan.
- Dev-only Site Control unlock: Shift+D, then type `reverity` within 6 seconds.
- Separate ADD NEW WORK form and EDIT EXISTING WORKS selector.
- Clicking EDIT opens a dedicated editor menu for the selected work.
- Built-in works can be edited or removed; custom works can be added, edited or removed.
- Roblox game importer accepts Roblox game URLs and attaches live public stats by Place ID.
- Games auto-refresh every 60 seconds and sort by current visits, with Heroes Battlegrounds pinned first.
- CONTRIBUTED VISITS is intentionally large and visually separated from its label.
- Commission availability can be switched between OPEN and CLOSED in Site Control and is shown publicly in Contact.
- Theme controls allow accent, background and panel colors.
- Current admin edits are stored in localStorage for this browser. A private backend/CMS would be required for secure cross-device persistence.
